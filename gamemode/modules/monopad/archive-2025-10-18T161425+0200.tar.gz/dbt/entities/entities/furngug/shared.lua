ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Печка"
ENT.Spawnable = true
ENT.Category = "DBT - Entity"

default_setting_pech = {
	[1] = 21,
	[2] = 22,
	[3] = 23,
	[4] = 24,
	[5] = 5,
	[6] = 6,
}
