include("shared.lua")


local triangle = Material("triangle.png")
