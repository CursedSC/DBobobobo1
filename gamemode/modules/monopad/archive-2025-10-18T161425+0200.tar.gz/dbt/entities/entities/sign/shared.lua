ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Записка"
ENT.Spawnable = false
ENT.Category = "DBT - Entity"


