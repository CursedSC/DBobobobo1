ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Чайник"
ENT.Spawnable = true
ENT.Category = "DBT - Entity"

default_setting_teapot = {
	[1] = 28,
	[2] = 13,
	[3] = 29,
	[4] = 30,
}
