ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Подарок"
ENT.Spawnable = false
ENT.Category = "DBT - Entity"

function ENT:Use(activator)
end