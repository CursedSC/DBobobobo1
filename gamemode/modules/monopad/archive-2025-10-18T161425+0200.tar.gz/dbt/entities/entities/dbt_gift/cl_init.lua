include("shared.lua")

function ENT:Draw()
	-- body
	self:DrawModel()
end

function ENT:Use(activator)
end