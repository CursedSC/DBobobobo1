ENT.Type = "anim"
ENT.Base = "base_gmodentity"
--
ENT.PrintName = "Тело"
ENT.Spawnable = false
ENT.Category = "DBT - Entity"
