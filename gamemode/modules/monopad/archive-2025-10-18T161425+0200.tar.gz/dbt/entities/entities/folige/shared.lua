ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Холодильник"
ENT.Spawnable = true
ENT.Category = "DBT - Entity"

default_setting_folig = {
	[1] = 7,
	[2] = 8,
	[3] = 9,
	[4] = 10,
	[5] = 11,
	[6] = 12,
	[7] = 14,
	[8] = 15,
}
