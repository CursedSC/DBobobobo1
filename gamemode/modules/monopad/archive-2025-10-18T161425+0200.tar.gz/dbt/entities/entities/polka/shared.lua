ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Полка с едой"
ENT.Spawnable = true
ENT.Category = "DBT - Entity"

default_setting_polka = {
	[1] = 17,
	[2] = 18,
	[3] = 19,
	[4] = 20,
	[5] = 13,
	[6] = 16,
}
