ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Медицинские инструменты"
ENT.Spawnable = true
ENT.Category = "DBT - Entity"
