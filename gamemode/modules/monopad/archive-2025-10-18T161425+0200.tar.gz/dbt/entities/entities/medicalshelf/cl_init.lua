include("shared.lua")

function ENT:Draw()
	-- body
	self:DrawModel()
end
