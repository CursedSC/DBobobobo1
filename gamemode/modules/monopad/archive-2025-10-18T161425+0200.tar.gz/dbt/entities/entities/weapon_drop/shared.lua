ENT.Type = "anim"
ENT.Base = "base_gmodentity"
--
ENT.PrintName = "Выброшеное оружие"
ENT.Spawnable = false
ENT.Category = "DBT - Entity"

