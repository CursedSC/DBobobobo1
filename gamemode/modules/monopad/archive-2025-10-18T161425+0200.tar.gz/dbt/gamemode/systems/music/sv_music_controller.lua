dbt.music = dbt.music or {}

function dbt.music.Play(id, idsong, IsCustom)
	local isMulty = GetGlobalBool("MusicMultyMod")
	local tableMusic = AlbumList
	if IsCustom then tableMusic = AlbumListCustom end
	if isMulty and AlbumListCustom[id] then tableMusic = AlbumListCustom end


	if not idsong then 
		song = tableMusic[id]:RandomSong()
	else 
		song = tableMusic[id]:GetSong(idsong)
	end 
	dbt.music.CurrentSong = {
		song = song,
		album = id
	}
	netstream.Start(nil, "dbt/controller/music/play", song.path, id, IsCustom)
end
   
netstream.Hook("dbt/controller/music/end", function()
	dbt.music.Play(dbt.music.CurrentSong.album)
end)

function dbt.music.StartDayNight()
	local s = globaltime % 60
	local tmp = math.floor( globaltime / 60 )
	local m = tmp % 60 
	local tmp = math.floor( tmp / 60 )
	local h = tmp % 24

	local IsNight = (h > 20 or h < 7)

	if IsNight then 
		dbt.music.Play("night")
	else 
		dbt.music.Play("day")
	end
end

netstream.Hook("dbt/music/start/admin", function(ply, album, id, IsCustom)
	dbt.music.Play(album, id, IsCustom)
end)
netstream.Hook("dbt/music/time", function(ply, t)
	if !ply:IsAdmin() then return end 
	netstream.Start(nil, "dbt/music/time", t)
end)

--[[
netstream.Hook("dbt/music/sync", function(ply)
	local Sync = {}
	for k, i in pairs(AlbumList) do 
		Sync[k] = {}
		Sync[k].name = i.name
		Sync[k].songs = {}
		for id, music in pairs(i.songs) do 
			Sync[k].songs[id] = {
				path = music.path, 
				name = music.name,
			}
		end
	end
	netstream.Start(ply, "dbt/music/sync", Sync)
end)]]
