CHARACTER = {}

function CHARACTER:__tostring()
    return "Персонаж[" .. self.name .. "]["..self.index.."]"
end

function CHARACTER:Init(name, tbl)
    local tbl = tbl or {}
    tbl.name = name
    self.backup = {}
    self.name = name 
    self.model = tbl.model or "models/player/Group01/female_01.mdl"
    self.male = tbl.male or false
    self.hugred = tbl.hugred or true 
    self.starving = tbl.starving or true  
    self.food = tbl.food or 1
    self.water = tbl.water or 1
    self.discord = tbl.discord
    self.sleep = tbl.sleep or 1
    self.season = tbl.season or 0
    self.char = tbl.char or 1
    self.attentiveness = tbl.attentiveness or 1
    self.color = tbl.color or Color(0,0,0)
    self.blacklistwep = tbl.blacklistwep or {}
    self.med_inv = tbl.med_inv or false
    self.absl = tbl.absl or ""
    self.emote = tbl.emote or 1
    self.maxKG = tbl.maxKG
    self.lock = tbl.lock
    self.backup = tbl
    
end

function CHARACTER:Update(tbl) 
    local tbl = tbl or {}
    print("Update start")
    for k,v in pairs(tbl) do
        print(k, v)
        self[k] = v
    end
end

function CHARACTER:SetModel(mdl)
    self.model = mdl
end

function CHARACTER:SetMale(b)
    self.male = b
end

function CHARACTER:SetHungred(b)
    self.hugred = b 
end 

function CHARACTER:SetStarving(b)
    self.starving = b 
end 

function CHARACTER:SetFood(n)
    self.food = n
end 

function CHARACTER:SetWater(n)
    self.water = n
end 

function CHARACTER:SetSleep(n)
    self.sleep = n
end 

function CHARACTER:SetSeason(n)
    self.season = n
end 

function CHARACTER:GetChar(n)
    self.char = n
end 

function CHARACTER:GetMale(b)
    return self.male
end

function CHARACTER:GetHungred(b)
    return self.hugred
end 

function CHARACTER:GetStarving(b)
    return self.starving
end 

function CHARACTER:GetFood(n)
    return self.food
end 

function CHARACTER:GetWater(n)
    return self.water
end 

function CHARACTER:GetSleep(n)
    return self.sleep
end 

function CHARACTER:GetSeason(n)
    return self.season
end 

function CHARACTER:GetChar(n)
    return self.char
end 

function CHARACTER:GetEmotes(n)
    return self.emote
end 

CHARACTER.__index = CHARACTER