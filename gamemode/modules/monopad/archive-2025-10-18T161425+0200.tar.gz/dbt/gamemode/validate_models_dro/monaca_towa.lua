player_manager.AddValidModel( "Monaca Towa", "models/dro/player/characters4/char6/char6.mdl" );
player_manager.AddValidHands( "Monaca Towa", "models/dro/player/characters4/char6/c_arms/char6_arms.mdl", 0, "00000000" );

 