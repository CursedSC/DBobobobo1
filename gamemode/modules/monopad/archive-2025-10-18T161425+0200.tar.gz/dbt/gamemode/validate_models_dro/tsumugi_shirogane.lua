player_manager.AddValidModel( "Tsumugi Shirogane", "models/dro/player/characters3/char14/char14.mdl" );
player_manager.AddValidHands( "Tsumugi Shirogane", "models/dro/player/characters3/char14/c_arms/char14_arms.mdl", 0, "00000000" )

 