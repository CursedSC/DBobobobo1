player_manager.AddValidModel( "Peko Pekoyama", "models/dro/player/characters2/char9/char9.mdl" );
player_manager.AddValidHands( "Peko Pekoyama", "models/dro/player/characters2/char9/c_arms/char9_arms.mdl", 0, "00000000" )

 