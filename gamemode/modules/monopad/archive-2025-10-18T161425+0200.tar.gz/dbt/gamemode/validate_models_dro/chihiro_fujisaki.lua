player_manager.AddValidModel( "Chihiro Fujisaki", "models/dro/player/characters1/char5/char5.mdl" );
player_manager.AddValidHands( "Chihiro Fujisaki", "models/dro/player/characters1/char5/c_arms/char5_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"