player_manager.AddValidModel( "Miu Iruma", "models/dro/player/characters3/char11/char11.mdl" );
player_manager.AddValidHands( "Miu Iruma", "models/dro/player/characters3/char11/c_arms/char11_arms.mdl", 0, "00000000" )

 