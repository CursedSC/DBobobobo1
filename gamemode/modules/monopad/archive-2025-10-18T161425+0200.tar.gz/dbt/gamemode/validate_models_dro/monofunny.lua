player_manager.AddValidModel( "Big Monofunny", "models/dro/player/characters10/char4/char4_big.mdl" );
player_manager.AddValidHands( "Big Monofunny", "models/dro/player/characters10/char4/c_arms/char4_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monofunny", "models/dro/player/characters10/char4/char4.mdl" );
player_manager.AddValidHands( "Monofunny", "models/dro/player/characters10/char4/c_arms/char4_big_arms.mdl", 0, "00000000" )

 