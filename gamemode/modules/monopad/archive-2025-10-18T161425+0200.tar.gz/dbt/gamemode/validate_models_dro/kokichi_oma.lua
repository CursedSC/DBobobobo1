player_manager.AddValidModel( "Kokichi Oma", "models/dro/player/characters3/char2/char2.mdl" );
player_manager.AddValidHands( "Kokichi Oma", "models/dro/player/characters3/char2/c_arms/char2_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Kokichi Oma Beta", "models/dro/player/characters3/char2/char2_beta.mdl" );
player_manager.AddValidHands( "Kokichi Oma Beta", "models/dro/player/characters3/char2/c_arms/char2_beta_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Kokichi Oma Uniform", "models/dro/player/characters3/char2/char2_uniform.mdl" );
player_manager.AddValidHands( "Kokichi Oma Uniform", "models/dro/player/characters3/char2/c_arms/char2_school_arms.mdl", 0, "00000000" )

 