player_manager.AddValidModel( "Big Monosuke", "models/dro/player/characters10/char3/char3_big.mdl" );
player_manager.AddValidHands( "Big Monosuke", "models/dro/player/characters10/char3/c_arms/char3_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monosuke", "models/dro/player/characters10/char3/char3.mdl" );
player_manager.AddValidHands( "Monosuke", "models/dro/player/characters10/char3/c_arms/char3_big_arms.mdl", 0, "00000000" )

 