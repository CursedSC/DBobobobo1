player_manager.AddValidModel( "Makoto Naegi", "models/dro/player/characters1/char1/char1.mdl" );
player_manager.AddValidHands( "Makoto Naegi", "models/dro/player/characters1/char1/c_arms/char1_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Makoto Naegi FF", "models/dro/player/characters1/char1/char1_uniformff.mdl" );
player_manager.AddValidHands( "Makoto Naegi FF", "models/dro/player/characters1/char1/c_arms/char1_uniformff_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Makoto Naegi HP", "models/dro/player/characters1/char1/char1_uniformhp.mdl" );
player_manager.AddValidHands( "Makoto Naegi HP", "models/dro/player/characters1/char1/c_arms/char1_uniformhp_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"