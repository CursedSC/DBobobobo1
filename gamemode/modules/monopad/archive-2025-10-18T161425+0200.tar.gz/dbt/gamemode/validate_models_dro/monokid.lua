player_manager.AddValidModel( "Big Monokid", "models/dro/player/characters10/char6/char6_big.mdl" );
player_manager.AddValidHands( "Big Monokid", "models/dro/player/characters10/char6/c_arms/char6_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monokid", "models/dro/player/characters10/char6/char6.mdl" );
player_manager.AddValidHands( "Monokid", "models/dro/player/characters10/char6/c_arms/char6_big_arms.mdl", 0, "00000000" )

 