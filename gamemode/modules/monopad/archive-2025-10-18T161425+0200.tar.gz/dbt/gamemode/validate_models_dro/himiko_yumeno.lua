player_manager.AddValidModel( "Himiko Yumeno", "models/dro/player/characters3/char12/char12.mdl" );
player_manager.AddValidHands( "Himiko Yumeno", "models/dro/player/characters3/char12/c_arms/char12_arms.mdl", 0, "00000000" )

 