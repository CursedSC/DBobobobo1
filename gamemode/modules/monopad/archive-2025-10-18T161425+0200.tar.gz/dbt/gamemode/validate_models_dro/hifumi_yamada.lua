player_manager.AddValidModel( "Hifumi Yamada", "models/dro/player/characters1/char13/char13.mdl" );
player_manager.AddValidHands( "Hifumi Yamada", "models/dro/player/characters1/char13/c_arms/char13_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"