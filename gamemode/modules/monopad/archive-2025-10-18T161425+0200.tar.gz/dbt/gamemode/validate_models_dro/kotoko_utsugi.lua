player_manager.AddValidModel( "Kotoko Utsugi", "models/dro/player/characters4/char5/char5.mdl" );
player_manager.AddValidHands( "Kotoko Utsugi", "models/dro/player/characters4/char5/c_arms/char5_arms.mdl", 0, "00000000" );

 