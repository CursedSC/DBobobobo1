player_manager.AddValidModel( "Maki Harukawa", "models/dro/player/characters3/char9/char9.mdl" );
player_manager.AddValidHands( "Maki Harukawa", "models/dro/player/characters3/char9/c_arms/char9_arms.mdl", 0, "00000000" )

 