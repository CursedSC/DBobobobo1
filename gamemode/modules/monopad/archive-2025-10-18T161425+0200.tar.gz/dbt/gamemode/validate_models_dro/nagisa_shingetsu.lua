player_manager.AddValidModel( "Nagisa Shingetsu", "models/dro/player/characters4/char4/char4.mdl" );
player_manager.AddValidHands( "Nagisa Shingetsu", "models/dro/player/characters4/char4/c_arms/char4_arms.mdl", 0, "00000000" );

 