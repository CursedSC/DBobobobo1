player_manager.AddValidModel( "Tenko Chabashira", "models/dro/player/characters3/char10/char10.mdl" );
player_manager.AddValidHands( "Tenko Chabashira", "models/dro/player/characters3/char10/c_arms/char10_arms.mdl", 0, "00000000" )

 