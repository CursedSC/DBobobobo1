player_manager.AddValidModel( "Sayaka Maizono", "models/dro/player/characters1/char7/char7.mdl" );
player_manager.AddValidHands( "Sayaka Maizono", "models/dro/player/characters1/char7/c_arms/char7_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"