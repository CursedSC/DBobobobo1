player_manager.AddValidModel( "Kaito Momota", "models/dro/player/characters3/char4/char4.mdl" );
player_manager.AddValidHands( "Kaito Momota", "models/dro/player/characters3/char4/c_arms/char4_arms.mdl", 0, "00000000" )

 