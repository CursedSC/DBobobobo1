player_manager.AddValidModel( "K1-B0", "models/dro/player/characters3/char3/char3.mdl" );
player_manager.AddValidHands( "K1-B0", "models/dro/player/characters3/char3/c_arms/char3_arms.mdl", 0, "00000000" )

 