player_manager.AddValidModel( "Nagito Komaeda", "models/dro/player/characters2/char2/char2.mdl" );
player_manager.AddValidHands( "Nagito Komaeda", "models/dro/player/characters2/char2/c_arms/char2_arms.mdl", 0, "00000000" )

 