player_manager.AddValidModel( "Korekiyo Shinguji", "models/dro/player/characters3/char6/char6.mdl" );
player_manager.AddValidHands( "Korekiyo Shinguji", "models/dro/player/characters3/char6/c_arms/char6_arms.mdl", 0, "00000000" )

 