player_manager.AddValidModel( "Big Monokuma", "models/dro/player/characters10/char1/char1_big.mdl" );
player_manager.AddValidHands( "Big Monokuma", "models/dro/player/characters10/char1/c_arms/char1_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monokuma", "models/dro/player/characters10/char1/char1.mdl" );
player_manager.AddValidHands( "Monokuma", "models/dro/player/characters10/char1/c_arms/char1_big_arms.mdl", 0, "00000000" )

 