player_manager.AddValidModel( "Kyoko Kirigiri", "models/dro/player/characters1/char6/char6.mdl" );
player_manager.AddValidHands( "Kyoko Kirigiri", "models/dro/player/characters1/char6/c_arms/char6_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"