player_manager.AddValidModel( "Byakuya Togami", "models/dro/player/characters1/char2/char2.mdl" );
player_manager.AddValidHands( "Byakuya Togami", "models/dro/player/characters1/char2/c_arms/char2_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"