player_manager.AddValidModel( "ENA Mannequin", "models/player/xenonuke/EnaModels/enamannequin.mdl" );
list.Set( "PlayerOptionsModel", "ENA Mannequin", "models/player/xenonuke/EnaModels/enamannequin.mdl" );
player_manager.AddValidHands( "ENA Mannequin", "models/player/xenonuke/EnaModels/enamannequin_c_arms.mdl", 0, "00000000" )