player_manager.AddValidModel( "Gonta Gokuhara", "models/dro/player/characters3/char7/char7.mdl" );
player_manager.AddValidHands( "Gonta Gokuhara", "models/dro/player/characters3/char7/c_arms/char7_arms.mdl", 0, "00000000" )

 