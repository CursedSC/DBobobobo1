player_manager.AddValidModel( "Sonia Nevermind", "models/dro/player/characters2/char6/char6.mdl" );
player_manager.AddValidHands( "Sonia Nevermind", "models/dro/player/characters2/char6/c_arms/char6_arms.mdl", 0, "00000000" )

 