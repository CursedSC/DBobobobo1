player_manager.AddValidModel( "Ryoko Otonashi", "models/dro/player/characters5/char1/char1.mdl" );
player_manager.AddValidHands( "Ryoko Otonashi", "models/dro/player/characters5/char1/c_arms/char1_arms.mdl", 0, "00000000" );

 