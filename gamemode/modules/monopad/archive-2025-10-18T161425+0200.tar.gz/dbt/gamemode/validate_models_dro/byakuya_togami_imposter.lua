player_manager.AddValidModel( "Byakuya Togami (Danganronpa 2)", "models/dro/player/characters2/char13/char13.mdl" );
player_manager.AddValidHands( "Byakuya Togami (Danganronpa 2)", "models/dro/player/characters2/char13/c_arms/char13_arms.mdl", 0, "00000000" )

 