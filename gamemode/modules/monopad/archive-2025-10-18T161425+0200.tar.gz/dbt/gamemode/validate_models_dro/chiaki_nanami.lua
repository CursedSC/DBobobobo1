player_manager.AddValidModel( "Chiaki Nanami", "models/dro/player/characters2/char7/char7.mdl" );
player_manager.AddValidHands( "Chiaki Nanami", "models/dro/player/characters2/char7/c_arms/char7_arms.mdl", 0, "00000000" )

 