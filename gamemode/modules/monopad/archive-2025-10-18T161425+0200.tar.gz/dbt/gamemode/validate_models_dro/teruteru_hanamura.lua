player_manager.AddValidModel( "Teruteru Hanamura", "models/dro/player/characters2/char15/char15.mdl" );
player_manager.AddValidHands( "Teruteru Hanamura", "models/dro/player/characters2/char15/c_arms/char15_arms.mdl", 0, "00000000" )

 