player_manager.AddValidModel( "Kirumi Tojo", "models/dro/player/characters3/char13/char13.mdl" );
player_manager.AddValidHands( "Kirumi Tojo", "models/dro/player/characters3/char13/c_arms/char13_arms.mdl", 0, "00000000" )

 