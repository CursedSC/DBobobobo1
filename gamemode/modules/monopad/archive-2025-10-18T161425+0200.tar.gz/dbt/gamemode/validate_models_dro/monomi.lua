player_manager.AddValidModel( "Big Monomi", "models/dro/player/characters10/char2/char2_big.mdl" );
player_manager.AddValidHands( "Big Monomi", "models/dro/player/characters10/char2/c_arms/char2_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monomi", "models/dro/player/characters10/char2/char2.mdl" );
player_manager.AddValidHands( "Monomi", "models/dro/player/characters10/char2/c_arms/char2_big_arms.mdl", 0, "00000000" )

 