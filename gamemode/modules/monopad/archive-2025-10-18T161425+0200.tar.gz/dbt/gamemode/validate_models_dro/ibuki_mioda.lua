player_manager.AddValidModel( "Ibuki Mioda", "models/dro/player/characters2/char5/char5.mdl" );
player_manager.AddValidHands( "Ibuki Mioda", "models/dro/player/characters2/char5/c_arms/char5_arms.mdl", 0, "00000000" )

 