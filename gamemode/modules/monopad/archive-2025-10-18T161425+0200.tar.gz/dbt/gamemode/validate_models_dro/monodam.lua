player_manager.AddValidModel( "Big Monodam", "models/dro/player/characters10/char5/char5_big.mdl" );
player_manager.AddValidHands( "Big Monodam", "models/dro/player/characters10/char5/c_arms/char5_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monodam", "models/dro/player/characters10/char5/char5.mdl" );
player_manager.AddValidHands( "Monodam", "models/dro/player/characters10/char5/c_arms/char5_big_arms.mdl", 0, "00000000" )

 