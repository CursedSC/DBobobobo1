player_manager.AddValidModel( "Jataro Kemuri", "models/dro/player/characters4/char2/char2.mdl" );
player_manager.AddValidHands( "Jataro Kemuri", "models/dro/player/characters4/char2/c_arms/char2_arms.mdl", 0, "00000000" );

 