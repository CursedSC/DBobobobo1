player_manager.AddValidModel( "Leon Kuwata", "models/dro/player/characters1/char14/char14.mdl" );
player_manager.AddValidHands( "Leon Kuwata", "models/dro/player/characters1/char14/c_arms/char14_arms.mdl", 0, "00000000" )

 