player_manager.AddValidModel( "Gundham Tanaka", "models/dro/player/characters2/char3/char3.mdl" );
player_manager.AddValidHands( "Gundham Tanaka", "models/dro/player/characters2/char3/c_arms/char3_arms.mdl", 0, "00000000" )

 