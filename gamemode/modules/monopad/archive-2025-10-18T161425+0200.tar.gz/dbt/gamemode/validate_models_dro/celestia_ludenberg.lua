player_manager.AddValidModel( "Celestia Ludenberg", "models/dro/player/characters1/char8/char8.mdl" );
player_manager.AddValidHands( "Celestia Ludenberg", "models/dro/player/characters1/char8/c_arms/char8_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"