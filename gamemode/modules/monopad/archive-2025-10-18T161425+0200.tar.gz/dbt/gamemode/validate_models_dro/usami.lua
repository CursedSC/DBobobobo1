player_manager.AddValidModel( "Big Usami", "models/dro/player/characters10/char2/char2_usami_big.mdl" );
player_manager.AddValidHands( "Big Usami", "models/dro/player/characters10/char2/c_arms/char2_usami_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Usami", "models/dro/player/characters10/char2/char2_usami.mdl" );
player_manager.AddValidHands( "Usami", "models/dro/player/characters10/char2/c_arms/char2_usami_big_arms.mdl", 0, "00000000" )

 