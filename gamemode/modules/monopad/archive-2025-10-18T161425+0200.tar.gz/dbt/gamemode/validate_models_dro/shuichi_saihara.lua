player_manager.AddValidModel( "Shuichi Saihara", "models/dro/player/characters3/char1/char1.mdl" );
player_manager.AddValidHands( "Shuichi Saihara", "models/dro/player/characters3/char1/c_arms/char1_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Shuichi Saihara Fem", "models/dro/player/characters3/char1/char1_fem.mdl" );
player_manager.AddValidHands( "Shuichi Saihara Fem", "models/dro/player/characters3/char1/c_arms/char1_fem_arms.mdl", 0, "00000000" )

 