player_manager.AddValidModel( "Akane Owari", "models/dro/player/characters2/char11/char11.mdl" );
player_manager.AddValidHands( "Akane Owari", "models/dro/player/characters2/char11/c_arms/char11_arms.mdl", 0, "00000000" )

 