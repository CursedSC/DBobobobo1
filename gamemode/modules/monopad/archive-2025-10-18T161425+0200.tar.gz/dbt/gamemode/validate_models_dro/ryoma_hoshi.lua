player_manager.AddValidModel( "Ryoma Hoshi", "models/dro/player/characters3/char16/char16.mdl" );
player_manager.AddValidHands( "Ryoma Hoshi", "models/dro/player/characters3/char16/c_arms/char16_arms.mdl", 0, "00000000" )

 