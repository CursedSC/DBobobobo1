player_manager.AddValidModel( "Sakura Ogami", "models/dro/player/characters1/char12/char12.mdl" );
player_manager.AddValidHands( "Sakura Ogami", "models/dro/player/characters1/char12/c_arms/char12_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"