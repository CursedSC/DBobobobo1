player_manager.AddValidModel( "Angie Yonaga", "models/dro/player/characters3/char15/char15.mdl" );
player_manager.AddValidHands( "Angie Yonaga", "models/dro/player/characters3/char15/c_arms/char15_arms.mdl", 0, "00000000" )

 