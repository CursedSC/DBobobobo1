player_manager.AddValidModel( "Big Monotaro", "models/dro/player/characters10/char7/char7_big.mdl" );
player_manager.AddValidHands( "Big Monotaro", "models/dro/player/characters10/char7/c_arms/char7_big_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Monotaro", "models/dro/player/characters10/char7/char7.mdl" );
player_manager.AddValidHands( "Monotaro", "models/dro/player/characters10/char7/c_arms/char7_big_arms.mdl", 0, "00000000" )

 