player_manager.AddValidModel( "Rantaro Amami", "models/dro/player/characters3/char5/char5.mdl" );
player_manager.AddValidHands( "Rantaro Amami", "models/dro/player/characters3/char5/c_arms/char5_arms.mdl", 0, "00000000" )

 