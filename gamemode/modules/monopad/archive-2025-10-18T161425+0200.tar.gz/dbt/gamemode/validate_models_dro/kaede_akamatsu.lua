player_manager.AddValidModel( "Kaede Akamatsu", "models/dro/player/characters3/char8/char8.mdl" );
player_manager.AddValidHands( "Kaede Akamatsu", "models/dro/player/characters3/char8/c_arms/char8_arms.mdl", 0, "00000000" )

 