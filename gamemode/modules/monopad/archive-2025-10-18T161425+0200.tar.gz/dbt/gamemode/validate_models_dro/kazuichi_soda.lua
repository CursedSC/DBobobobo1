player_manager.AddValidModel( "Kazuichi Soda 2", "models/dro/player/characters2/char16/char16.mdl" );
player_manager.AddValidHands( "Kazuichi Soda 2", "models/dro/player/characters2/char16/c_arms/char16_arms.mdl", 0, "00000000" )

 