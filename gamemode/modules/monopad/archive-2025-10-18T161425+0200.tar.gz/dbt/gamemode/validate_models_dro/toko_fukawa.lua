player_manager.AddValidModel( "Toko Fukawa", "models/dro/player/characters1/char10/char10.mdl" );
player_manager.AddValidHands( "Toko Fukawa", "models/dro/player/characters1/char10/c_arms/char10_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Genocide Jack", "models/dro/player/characters1/char10/char10_genocide.mdl" );
player_manager.AddValidHands( "Genocide Jack", "models/dro/player/characters1/char10/c_arms/char10_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"