player_manager.AddValidModel( "Mikan Tsumiki", "models/dro/player/characters2/char8/char8.mdl" );
player_manager.AddValidHands( "Mikan Tsumiki", "models/dro/player/characters2/char8/c_arms/char8_arms.mdl", 0, "00000000" )

 