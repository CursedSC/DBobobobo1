player_manager.AddValidModel( "Hajime Hinata", "models/dro/player/characters2/char1/char1.mdl" );
player_manager.AddValidHands( "Hajime Hinata", "models/dro/player/characters2/char1/c_arms/char1_arms.mdl", 0, "00000000" )

 