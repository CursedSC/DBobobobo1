player_manager.AddValidModel( "Mahiru Koizumi", "models/dro/player/characters2/char10/char10.mdl" );
player_manager.AddValidHands( "Mahiru Koizumi", "models/dro/player/characters2/char10/c_arms/char10_arms.mdl", 0, "00000000" )

 