player_manager.AddValidModel( "Aoi Asahina", "models/dro/player/characters1/char11/char11.mdl" );
player_manager.AddValidHands( "Aoi Asahina", "models/dro/player/characters1/char11/c_arms/char11_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"