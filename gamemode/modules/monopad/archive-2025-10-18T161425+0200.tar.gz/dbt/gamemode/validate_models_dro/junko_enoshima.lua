player_manager.AddValidModel( "Junko Enoshima", "models/dro/player/characters1/char9/char9.mdl" );
player_manager.AddValidHands( "Junko Enoshima", "models/dro/player/characters1/char9/c_arms/char9_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "Junko Enoshima (Fake)", "models/dro/player/characters1/char9/char9_fake.mdl" );
player_manager.AddValidHands( "Junko Enoshima (Fake)", "models/dro/player/characters1/char9/c_arms/char9_arms.mdl", 0, "00000000" )

local Category = "Danganronpa Online"