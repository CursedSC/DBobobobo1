-- from incredible-gmod.ru with <3
-- https://github.com/Be1zebub/Small-GLua-Things/blob/master/multicolor-text.lua

-- it can render multi-line + multi-color text
-- this is a heavy function, you shouldnt call it every frame - use render targets to render text 1 time and copy it to the material
-- learn how to use rendertargets here: https://wiki.facepunch.com/gmod/render.PushRenderTarget
-- preview: https://cdn.discordapp.com/attachments/565108080300261398/1110373812970725377/2023-05-23_08-08-42.mp4


