--local HealMat = Material("menu/stats/heal.png")
--local HungerMat = Material("menu/stats/hunger.png")
--local SleepMat = Material("menu/stats/sleep.png")
--local ArmorMat = Material("menu/stats/armor.png")
--local WaterMat = Material("menu/stats/water.png")
--local MenuBg = Material("menu/bg.png")
--local bg = Material("qmenu/background.png")
--local MenuShadow = Material("menu/shadow.png")
--local MenuFrame = Material("menu/frame_a.png")
--local MenuFrame_c = Material("menu/frmae_c.png")
--local MenuFrame_d = Material("menu/frame_d.png")
--local MenuFrame_b = Material("menu/frame_b.png")
--local Inventory_bg = Material("dbt/qmenu_inv/dbt_inventory.png")
local l_SetDrawColor = surface.SetDrawColor
local l_SetMaterial = surface.SetMaterial
local l_DrawTexturedRect = surface.DrawTexturedRect
local l_DrawText = draw.DrawText
local ScreenWidth = ScreenWidth or ScrW()
local ScreenHeight = ScreenHeight or ScrH()
local linefornamemat = Material("dbt/qmenu/qmenu_underline_name.png")
local characterstatustitle = Material("dbt/qmenu/qmenu_stats.png", 'smooth')
--local qmenubg = Material("dbt/qmenu/qmenubg.png", 'smooth')
--local stats = Material("dbt/qmenu/qmenuicons.png", 'smooth')
local backgroundqmenu = Material("dbt/qmenu/qmenu_bg.png", 'smooth')
local qmenufood = Material("dbt/qmenu/qmenu_food.png", 'smooth')
local qmenusleep = Material("dbt/qmenu/qmenu_sleep.png", 'smooth')
local qmenuwater = Material("dbt/qmenu/qmenu_water.png", 'smooth')
local qmenuhp = Material("dbt/qmenu/qmenu_hp.png", 'smooth')
local qmenushield = Material("dbt/qmenu/qmenu_shield.png", 'smooth')
local scrw = ScrW()
local scrh = ScrH()
local meta = FindMetaTable("Player")
local linefornamematw, linefornamemath = linefornamemat:Width(), linefornamemat:Height()
local characterstatustitlew, characterstatustitleh = characterstatustitle:Width(), characterstatustitle:Height()
local iconsqmenuw, iconsqmenuh = qmenufood:Width(), qmenufood:Height()
local scrharmor = 0

q_alpha = 0
q_aplha_plates = 0
q_aplha_platesd = 0
CurrentQAlphaBlur = 0

local circles = include("dbt/gamemode/lib/demit/cl_circles.lua")

hook.Add("HUDPaint", "dbt/hud/inventory", function()
	local ply = LocalPlayer()
	local char_tbl = dbt.chr[ply:Pers()]
	if q_alpha >= 1 and not IsClassTrial() then
		local healthcircle = circles.New(CIRCLE_OUTLINED, 50, scrw*0.9637, scrh*0.28, 9)
		local watercircle = circles.New(CIRCLE_OUTLINED, 50, scrw*0.9637, scrh*0.42 + scrharmor, 9)
		local foodcircle = circles.New(CIRCLE_OUTLINED, 50, scrw*0.9637, scrh*0.56 + scrharmor, 9)
		local sleepcircle = circles.New(CIRCLE_OUTLINED, 50, scrw*0.9637, scrh*0.7 + scrharmor, 9)
		local armorcircle = circles.New(CIRCLE_OUTLINED, 50, scrw*0.9637, scrh*0.42, 9)

		local healthcirclebg = circles.New(CIRCLE_FILLED, 50, scrw*0.9637, scrh*0.28)
		local watercirclebg = circles.New(CIRCLE_FILLED, 50, scrw*0.9637, scrh*0.42 + scrharmor)
		local foodcirclebg = circles.New(CIRCLE_FILLED, 50, scrw*0.9637, scrh*0.56 + scrharmor)
		local sleepcirclebg = circles.New(CIRCLE_FILLED, 50, scrw*0.9637, scrh*0.7 + scrharmor)
		local armorcirclebg = circles.New(CIRCLE_FILLED, 50, scrw*0.9637, scrh*0.42)

		watercircle:SetRotation(270)
		foodcircle:SetRotation(270)
		sleepcircle:SetRotation(270)
		healthcircle:SetRotation(270)

		local blur = q_alpha / 255
		--CurrentQAlphaBlur = Lerp(FrameTime() * 5, CurrentQAlphaBlur, 24)
		BlurScreen(24 * blur)
		local scrhstatus = scrh*0.02
		surface.SetFont('Comfortaa X68')
		surface.SetDrawColor(0, 0, 0, math.Clamp(q_alpha, 0, 75))
		surface.DrawRect(0, 0, scrw, scrh)
		surface.SetDrawColor(255, 255, 255, q_alpha)

		l_SetMaterial(backgroundqmenu)
		l_DrawTexturedRect(0, 0, scrw, scrh)

		local widthname, heightname = surface.GetTextSize(dbt.chr[ply:Pers()].name)
		surface.DrawMulticolorText(scrw - widthname - scrw*0.015, -5, 'Comfortaa X68', {Color(255, 255, 255, q_alpha), dbt.chr[ply:Pers()].name}, scrw)
		PrintTable(woundstbl)
		if woundstbl then
			for k, v in pairs(woundstbl) do
				for a, b in pairs(v) do
					surface.DrawMulticolorText(scrw*0.039, scrhstatus, 'Comfortaa X37', {Color(255, 255, 255, q_alpha), '• '..b[1]..": "..k}, scrw)
					scrhstatus = scrhstatus + scrh*0.035
				end
			end
        end

		surface.SetFont('Comfortaa X35')
		local widthtalent, heighttalent = surface.GetTextSize(dbt.chr[ply:Pers()].absl)
		surface.DrawMulticolorText(scrw - widthtalent - scrw*0.015, scrh*0.08, 'Comfortaa X35', {Color(255, 255, 255, q_alpha), dbt.chr[ply:Pers()].absl}, scrw)

		surface.SetDrawColor(255, 255, 255, math.Clamp(q_alpha, 0, 190))
		l_SetMaterial(linefornamemat)
		l_DrawTexturedRect(scrw*0.76, scrh*0.06, linefornamematw, linefornamemath)

		--l_SetMaterial(stats)
		--l_DrawTexturedRect(scrw*0.926, 0, scrw*0.074, scrh)

		surface.SetDrawColor(0, 0, 0, math.Clamp(q_alpha, 0, 125))
		draw.NoTexture()
		healthcirclebg()
		watercirclebg()
		foodcirclebg()
		sleepcirclebg()
		local art = Material("dbt/characters"..char_tbl.season.."/char"..char_tbl.char.."/char_art.png", "smooth")
		local xCustom = (ply:Pers() == "Кёко Киригири") and dbtPaint.WidthSource(500) or dbtPaint.WidthSource(300)
		dbtPaint.DrawRectR(art, xCustom, scrh * .6, dbtPaint.WidthSource(975) * 1.3, dbtPaint.HightSource(989) * 1.3, 0, Color(255,255,255, math.Clamp(q_alpha, 0, 15)))

		surface.SetDrawColor(255, 255, 255, math.Clamp(q_alpha, 0, 190))
		l_SetMaterial(characterstatustitle)
		l_DrawTexturedRect(scrw*0.007, 5, characterstatustitlew*0.52, characterstatustitleh*0.52)

		surface.SetDrawColor(255, 255, 255, q_alpha)
		l_SetMaterial(qmenuhp)
		l_DrawTexturedRect(scrw*0.952, scrh*0.259, iconsqmenuw*0.09, iconsqmenuh*0.09)

		l_SetMaterial(qmenuwater)
		l_DrawTexturedRect(scrw*0.952, scrh*0.399 + scrharmor, iconsqmenuw*0.09, iconsqmenuh*0.09)

		l_SetMaterial(qmenufood)
		l_DrawTexturedRect(scrw*0.952, scrh*0.539 + scrharmor, iconsqmenuw*0.09, iconsqmenuh*0.09)

		l_SetMaterial(qmenusleep)
		l_DrawTexturedRect(scrw*0.952, scrh*0.679 + scrharmor, iconsqmenuw*0.09, iconsqmenuh*0.09)

		surface.SetDrawColor(117, 30, 132, q_alpha)
		draw.NoTexture()
		healthprocent = ply:Health() / ply:GetMaxHealth()
		healthcircle:SetEndAngle(healthprocent*360)
		healthcircle()

		watercircle:SetEndAngle(ply:GetNWInt("water") * 3.6)
		watercircle()


		foodcircle:SetEndAngle(ply:GetNWInt("hunger") * 3.6)
		foodcircle()

		sleepcircle:SetEndAngle(ply:GetNWInt("sleep") * 3.6)
		sleepcircle()

		if ply:Armor() > 0 then
			scrharmor = scrh*0.14
			armorcircle:SetRotation(270)

			surface.SetDrawColor(0, 0, 0, math.Clamp(q_alpha, 0, 125))
			draw.NoTexture()
			armorcirclebg()

			surface.SetDrawColor(255, 255, 255, q_alpha)
			l_SetMaterial(qmenushield)
			l_DrawTexturedRect(scrw*0.952, scrh*0.399, iconsqmenuw*0.09, iconsqmenuh*0.09)

			surface.SetDrawColor(130, 130, 130, q_alpha)
			draw.NoTexture()
			armorprocent = ply:Armor() / ply:GetMaxArmor()
			armorcircle:SetEndAngle(armorprocent*360)
			armorcircle()
		else
			scrharmor = 0
		end

        if dbt.inventory.info.monopad and dbt.inventory.info.monopad.id then
            local globaltime = GetGlobalInt("Time")
            local    s = globaltime % 60
            local    tmp = math.floor( globaltime / 60 )
            local    m = tmp % 60
            local    tmp = math.floor( tmp / 60 )
            local    h = tmp % 24
            local curtimesys = string.format( "%02i:%02i", h, m)
            local time = h
            local time_ = m
            l_DrawText(string.format( "%02i:%02i", time, time_), "Comfortaa X70", ScreenWidth * 0.01, ScreenHeight * 0.93, Color(255,255,255,q_alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
        end
    end
end)
