PushSound = {}
PushSound[1] = Sound("actions/push/push1.wav")
PushSound[2] = Sound("actions/push/push2.wav")
PushSound[3] = Sound("actions/push/push3.wav")
PushSound[4] = Sound("actions/push/push4.wav")
