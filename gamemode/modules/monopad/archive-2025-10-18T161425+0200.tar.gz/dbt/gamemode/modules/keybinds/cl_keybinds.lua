hook.Add( "PlayerBindPress", "DisableBeind", function( ply, bind, pressed )
	
end )