res_time = CurTime()
hook.Add("ScalePlayerDamage", "dbt.RegisterDMG", function(ply, hitgroup, dmginfo)
--[[
	if res_time <= CurTime() then 
		net.Start("dbt.RegisterDMG.print")
		net.WriteEntity(ply)
		net.WriteFloat(hitgroup)
		net.SendToServer()
		res_time = CurTime() + 5
	end]]
end)