hook.Add( "PlayerDeathSound", "CustomPlayerDeath", function( ply )
	return true
end )
