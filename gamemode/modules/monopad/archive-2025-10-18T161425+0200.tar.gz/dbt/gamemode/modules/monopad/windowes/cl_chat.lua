local PANEL = {}
local minimumMessageY = dbtPaint.HightSource(50)
local bgColor = Color(29,29,29,255)
local bgColor2 = Color(48,48,48,255)
local borderColor = Color(73,73,73)
local textColor = Color(160,160,160)
local textColor2 = Color(160,160,160, 200)
local contactColor = Color(37,37,37)
local msgColor = Color(37,37,37, 200)
local msgColor2 = Color(47,47,47, 200)
local textEntryColor = Color(40,40,40)
local placeHolderColor = Color(160,160,160, 100)
local selectedColor = Color(145,0,190, 255)
local xMat = Material("dbt/monopad/X.png")
local msgMat = Material("dbt/monopad/Messages.png")
local paternMat = Material("dbt/monopad/paternm.png")
local test = http.Material("https://imgur.com/kW1R5tk.png")

local getTimeFrom = function(int)
    local globaltime = int
    local    s = globaltime % 60
    local    tmp = math.floor( globaltime / 60 )
    local    m = tmp % 60
    local    tmp = math.floor( tmp / 60 )
    local    h = tmp % 24

    local    days = math.floor( tmp / 24 )

    return string.format( "%02i:%02i", h, m), h, math.floor(days)
end

local function send_msg(text, mymonopad, tomonopad, monoid)
    netstream.Start("dbt/monopad/send/dms", mymonopad, tomonopad, text, monoid)
end

function PANEL:Init()

    self.ActiveChat = "chat"
    self.NameToID = {}
	self:SetFocusTopLevel( true )

	self:SetDraggable( true )
	self:SetSizable( false )
	self:SetScreenLock( true )
	self:SetDeleteOnClose( true )

	self:SetMinWidth( 50 )
	self:SetMinHeight( 50 )

	-- This turns off the engine drawing
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )
    self:ShowCloseButton(false)
	self.m_fCreateTime = SysTime()

	self.CloseB = vgui.Create( "DButton", self )
	self.CloseB:SetText( "" )
    self.CloseB:SetSize(dbtPaint.WidthSource(41), dbtPaint.HightSource(21))
    self.CloseB:SetPos(dbtPaint.WidthSource(597 - 41), 0)
	self.CloseB.DoClick = function ( button ) self:Close() end
	self.CloseB.Paint = function( panel, w, h )
        draw.RoundedBox(0,0,0,w,h,borderColor)
        draw.RoundedBox(0,1,1,w-2,h-2,bgColor2)
        dbtPaint.DrawRect(xMat, w / 2 - 5.5, h / 2 - 5.5, 11, 11, color_white)

    end

	self.ListContactsBg = vgui.Create( "EditablePanel", self )
    self.ListContactsBg:SetSize(dbtPaint.WidthSource(188), dbtPaint.HightSource(632))
    self.ListContactsBg:SetPos(0, dbtPaint.HightSource(20))
	self.ListContactsBg.Paint = function( panel, w, h )
        draw.RoundedBox(0,0,0,w,h,borderColor)
        draw.RoundedBox(0,1,1,w-2,h-2,bgColor)
    end
    self.ListContacts = vgui.Create( "DScrollPanel", self.ListContactsBg )
    self.ListContacts:SetSize(dbtPaint.WidthSource(288), dbtPaint.HightSource(625))
    self.ListContacts:SetPos(0, 4)
    local sbar = self.ListContacts:GetVBar()
    function sbar:Paint(w, h) end
    function sbar.btnUp:Paint(w, h) end
    function sbar.btnDown:Paint(w, h) end
    function sbar.btnGrip:Paint(w, h) end

    --self:BuildContacts()


	self.ListMessageBg = vgui.Create( "EditablePanel", self )
    self.ListMessageBg:SetSize(dbtPaint.WidthSource(410), dbtPaint.HightSource(635))
    self.ListMessageBg:SetPos(dbtPaint.WidthSource(187), dbtPaint.HightSource(20))
	self.ListMessageBg.Paint = function( panel, w, h )
    end

    self.TextEntryBg = vgui.Create( "EditablePanel", self.ListMessageBg )
    self.TextEntryBg:SetSize(dbtPaint.WidthSource(408), dbtPaint.HightSource(26))
    self.TextEntryBg:SetPos(dbtPaint.WidthSource(1), dbtPaint.HightSource(605))
	self.TextEntryBg.Paint = function( panel, w, h )
        draw.RoundedBox(0,0,0,w,h,textEntryColor)
    end
    local pers = LocalPlayer():GetMonopadOwner()
    self.TextEntry = vgui.Create( "DTextEntry", self.TextEntryBg ) -- create the form as a child of frame
    self.TextEntry:SetSize(dbtPaint.WidthSource(408), dbtPaint.HightSource(22))
    self.TextEntry:SetPos(0, 0)
    self.TextEntry:SetFont("Comfortaa X25")
    self.TextEntry:SetPaintBackground(false)
    self.TextEntry:SetPlaceholderText( "Сообщение" )
    self.TextEntry:SetPlaceholderColor( placeHolderColor )
    self.TextEntry:SetTextColor(textColor)
    self.TextEntry:SetDrawLanguageID(false)
    self.TextEntry.OnEnter = function( panel )
        if panel:GetValue() == "" then return end
        send_msg(panel:GetValue(), dbt.inventory.info.monopad.meta.id, self.ActiveChat, self.NameToID[self.ActiveChat])
        self:AddMessage(panel:GetValue(), pers, GetGlobalInt("Time"))
        panel:RequestFocus()
        panel:SetText("")
    end

    self.ListMessage = vgui.Create( "DScrollPanel", self.ListMessageBg )
    self.ListMessage:SetSize(dbtPaint.WidthSource(430), dbtPaint.HightSource(600))
    self.ListMessage:SetPos(0, 2)
    local sbar = self.ListMessage:GetVBar()
    function sbar:Paint(w, h) end
    function sbar.btnUp:Paint(w, h) end
    function sbar.btnDown:Paint(w, h) end
    function sbar.btnGrip:Paint(w, h) end

    self.yMessage= 7
end

local mat_circile = CreateMaterial( "circle", "UnlitGeneric", {
    ["$basetexture"] = "dbt/dbt_circle.vtf",
    ["$alphatest"] = 1,
    ["$vertexalpha"] = 1,
    ["$vertexcolor"] = 1,
    ["$smooth"] = 1,
    ["$mips"] = 1,
    ["$allowalphatocoverage"] = 1,
    ["$alphatestreference "] = 0.8,
} )

local cases = {[0] = 3, [1] = 1, [2] = 2, [3] = 2, [4] = 2, [5] = 3}
function pluralize(n, titles)
	n = math.floor(math.abs(n))
	return titles[
		(n % 100 > 4 and n % 100 < 20) and 3 or
		cases[(n % 10 < 5) and n % 10 or 5]
	]
end

local function isURL(str)
    local pattern = "^(https?://)"
    return string.match(str, pattern) ~= nil
end

-- Функция для проверки, содержит ли URL домен imgur.com
local function isImgurLink(str)
    local imgurPattern = "^(https?://)(www%.|m%.|)(imgur%.com)"
    return string.match(str, imgurPattern) ~= nil
end

MASAGECOUNT = 1
function PANEL:AddMessage(text, author, time)
    local time = time or 0
    local t, h, d = getTimeFrom(time)
    local t2, h2, d2 = getTimeFrom(GetGlobalInt("Time"))
    local d3 = d2 - d
    local timeSnap = ""
    if d3 >= 1 then
        timeSnap = d3.." "..pluralize(d3, {"день", "дня", "дня", "дня", "дней"}).." назад, "
    end
    local pers = LocalPlayer():GetMonopadOwner()
    local color = textColor
    if !isstring(author) then author = "????????" else color = dbt.chr[author].color end
    local isMy = (pers == author)

    local x, y = surface.DrawMulticolorText(weight_source(0), hight_source(0), "Comfortaa X20", { textColor, text}, weight_source(270))
    local textY = y + dbtPaint.HightSource(59)
    if textY < dbtPaint.HightSource(50) then
        textY = minimumMessageY
    end
    local Message = self.ListMessage:Add( "DButton" )
    Message.Color = textColor
    Message:SetText("")
    Message.text = text
    Message.subColor = color
    Message.id = MASAGECOUNT
    Message.CanDelete = true
    Message:SetText( "" )
    Message:SetSize(dbtPaint.WidthSource(350), dbtPaint.HightSource(textY))
    Message:SetPos(isMy and dbtPaint.WidthSource(53) or dbtPaint.WidthSource(7), self.yMessage)
    local char_tbl = dbt.chr[author]
    --Использование спрайта аргумента
    local material = Material("dbt/characters"..char_tbl.season.."/char"..char_tbl.char.."/ct_argue_1.png", "smooth")
    local UseArgue = true
    local material2 = Material("dbt/characters"..char_tbl.season.."/char"..char_tbl.char.."/char_ico_1.png", "smooth")
    Message.DoRightClick = function(panel)
        local menu = DermaMenu()
        menu:AddOption( "Копировать", function()
            SetClipboardText(panel.text)
        end )

        menu:Open()
    end

    local mat
    local w,h
    local _isUrl = isURL(text)
    local _isImgurLink = isImgurLink(text)
    if _isUrl and _isImgurLink then
        mat = HTTP_IMG(text)
        wimg,himg = mat:GetMaterial():Width(), mat:GetMaterial():Height()
    end
    local nameCharacter = CharacterNameOnName(author) 
	Message.Paint = function( panel, w, h )
        draw.RoundedBox(6,0,0,w,h, isMy and msgColor2 or msgColor)
        draw.SimpleText(nameCharacter, "Comfortaa X24", dbtPaint.WidthSource(55), hight_source(2), panel.subColor, TEXT_ALIGN_LEFT)


        draw.SimpleText(timeSnap..t, "Comfortaa X15", w - dbtPaint.WidthSource(6), h - hight_source(17), textColor2, TEXT_ALIGN_RIGHT)

        if _isUrl and _isImgurLink and mat.material then
            surface.SetDrawColor(255, 255, 255)
            surface.SetMaterial(mat.material)
            surface.DrawTexturedRect(55, 55, wimg - 55, himg - 55)
        else
            local x, y = surface.DrawMulticolorText(weight_source(55), hight_source(25), "Comfortaa X20", { textColor, text}, weight_source(270))


            dbtPaint.StartStencil()
                surface.SetDrawColor( 255,255,255,255)
	            surface.SetMaterial( mat_circile )
	            surface.DrawTexturedRect( dbtPaint.WidthSource(5), dbtPaint.HightSource(5), dbtPaint.WidthSource(40), dbtPaint.HightSource(40))
            --char_ico_1
            dbtPaint.ApllyStencil()
	            surface.SetDrawColor( 255, 255, 255, 255 )
	            surface.SetMaterial( material2 )
	            surface.DrawTexturedRect( dbtPaint.WidthSource(3), dbtPaint.HightSource(3), dbtPaint.WidthSource(45), dbtPaint.HightSource(45))
            render.SetStencilEnable( false )
        end

    end
    MASAGECOUNT = MASAGECOUNT + 1
    self.yMessage = self.yMessage + textY + dbtPaint.HightSource(7)
    self.ListMessage:GetVBar():AnimateTo( self.yMessage, 0.5, 0, 0.5 )
end

function PANEL:BuildContacts(MonopadsList)
    self.yContact = dbtPaint.HightSource(0)

    local Contact = self.ListContacts:Add( "DButton" )
    Contact.Name = "Общий чат"
    Contact.Color = textColor
    Contact:SetText( "" )
    Contact:SetSize(dbtPaint.WidthSource(180), dbtPaint.HightSource(33))
    Contact:SetPos(dbtPaint.WidthSource(4), self.yContact)

    local lenName = utf8.len(Contact.Name)
    if lenName > 14 then
        Contact.Name = utf8.sub(Contact.Name, 0, 14).."..."
    end

	Contact.Paint = function( panel, w, h )
        draw.RoundedBox(0,0,0,w,h,contactColor)
        local textToDraw = panel.Name
        local isSelected = ("chat" == self.ActiveChat )
        if isSelected then
            textToDraw = "> "..panel.Name
        end
        draw.SimpleText(textToDraw, "Comfortaa X28", dbtPaint.WidthSource(5), -1, isSelected and monopad.MainColorC or panel.Color, TEXT_ALIGN_LEFT)
    end
    Contact.DoClick = function(panel)
        monopadChat.ActiveChat = "chat"
        netstream.Start("dbt/monopad/request/dms", dbt.inventory.info.monopad.meta.id, monopadChat.ActiveChat)
        monopadChat.TextEntry:RequestFocus()
		surface.PlaySound('monopad_click.mp3')
    end

    self.yContact = self.yContact + dbtPaint.HightSource(37)

    for k, i in pairs(MonopadsList) do
    	local Contact = self.ListContacts:Add( "DButton" )
        Contact.Name = i.character
        Contact.Name2 =  CharacterNameOnName(i.character)  
        Contact.Color = textColor
        self.NameToID[i.character] = i.id
    	Contact:SetText( "" )
        Contact:SetSize(dbtPaint.WidthSource(180), dbtPaint.HightSource(33))
    	Contact:SetPos(dbtPaint.WidthSource(4), self.yContact)
        local lenName = utf8.len(Contact.Name)
        if lenName > 14 then
            Contact.Name2 = utf8.sub(Contact.Name2, 0, 14).."..."
        end


	    Contact.Paint = function( panel, w, h )
            draw.RoundedBox(0,0,0,w,h,contactColor)

            local textToDraw = panel.Name2
            local isSelected = (panel.Name == self.ActiveChat )
            if isSelected then
                textToDraw = "> "..panel.Name2
            end

            draw.SimpleText(textToDraw, "Comfortaa X28", dbtPaint.WidthSource(5), -1, isSelected and monopad.MainColorC or panel.Color, TEXT_ALIGN_LEFT)
        end
        Contact.DoClick = function(panel)
            self.ActiveChat = panel.Name
            netstream.Start("dbt/monopad/request/dms", dbt.inventory.info.monopad.meta.id, i.id)
            monopadChat.TextEntry:RequestFocus()
			surface.PlaySound('monopad_click.mp3')
        end

        self.yContact = self.yContact + dbtPaint.HightSource(37)
    end
    PrintTable(self.NameToID)
end

--paternMat
function PANEL:Paint(w,h)
    draw.RoundedBox(0,0,0,w,h,borderColor)
    draw.RoundedBox(0,1,1,w-2,h-2,bgColor)
    draw.RoundedBox(0, 1, 1, w - 2, dbtPaint.HightSource(20) - 1, bgColor2)
    draw.RoundedBox(0,0,dbtPaint.HightSource(20), w, 1, borderColor)
    if self.Dragging then self:RequestFocus() self.IsDragged = true end
    draw.SimpleText("Монограм", "Comfortaa X20", dbtPaint.WidthSource(25), -1, textColor, TEXT_ALIGN_LEFT)
    dbtPaint.DrawRect(msgMat, dbtPaint.WidthSource(5), dbtPaint.HightSource(3), dbtPaint.WidthSource(17), dbtPaint.HightSource(14), color_white)
    dbtPaint.DrawRect(paternMat, 0, dbtPaint.HightSource(21), dbtPaint.WidthSource(595), dbtPaint.HightSource(630), color_white)
end

netstream.Hook("dbt/monopad/request/chats", function(MonopadsList)
    PrintTable(MonopadsList)
    monopadChat:BuildContacts(MonopadsList)
end)

netstream.Hook("dbt/monopad/request/dms", function(DirectMessages)
    local msges = monopadChat.ListMessage:GetCanvas():GetChildren()
    for k, i in pairs(msges) do
        if i and IsValid(i) and i.CanDelete then
           i:Remove()
        end
    end
    monopadChat.yMessage = 7
    for k,i in pairs(DirectMessages) do
        monopadChat:AddMessage(i.message, i.own, i.time)
    end
end)

netstream.Hook("monopad/chat/add", function(chatid, msgtable)
    if !IsValid(monopadChat) then return end
    local pers = LocalPlayer():GetMonopadOwner()
    if chatid == "chat" and msgtable.own == pers then return end
    if chatid != monopadChat.ActiveChat then return end
    if chatid == "chat" then
        monopadChat:AddMessage(msgtable.message, msgtable.own, msgtable.time)
    end
    if chatid == monopadChat.NameToID[monopadChat.ActiveChat] then monopadChat:AddMessage(msgtable.message, msgtable.own, msgtable.time) end
end)

netstream.Hook("monopad/chat/show", function(id, msgtable)
    local pers = LocalPlayer():GetMonopadOwner()
    PrintTable(msgtable)
    if IsValid(monopadChat) then return end

    local globaltime = GetGlobalInt("Time")
    local    s = globaltime % 60
    local    tmp = math.floor( globaltime / 60 )
    local    m = tmp % 60
    local    tmp = math.floor( tmp / 60 )
    local    h = tmp % 24
    local curtimesys = string.format( "%02i:%02i", h, m)
	/*
    MSG_SENDER = msgtable.own
    MSG_TIME = curtimesys
    MSG_bool = (utf8.len(msgtable.message) > 85)
    MSG_TEXT = utf8.sub(msgtable.message, 1, 85)
    see_msg = true
    see_r = false
    MSG_CAN_LERP1 = false
    MSG_ALPHA1 = 255
    MSG_ALPHA2 = weight_source(1080 - 984)
    timer.Remove("MSG1")
    timer.Create("MSG", 2.5, 1, function()
        MSG_CAN_LERP1 = true
        timer.Create("MSG1", 2, 1, function() see_msg = false end)
    end)*/
	local char_tbl = dbt.chr[msgtable.own]
	surface.PlaySound('chat_uved.mp3')
	notifications_new(4, {icon = "dbt/characters"..char_tbl.season.."/char"..char_tbl.char.."/char_ico_1.png", title = msgtable.own, time = curtimesys, notiftext = msgtable.message})
end)

netstream.Hook("monopad/chat/notiftoall", function(msg, char)
    local pers = LocalPlayer():GetMonopadOwner()
    if char == pers then return end
    if IsValid(monopadChat) then return end
    if dbt.inventory.info.monopad and dbt.inventory.info.monopad.id then
		local globaltime = GetGlobalInt("Time")
	    local    s = globaltime % 60
	    local    tmp = math.floor( globaltime / 60 )
	    local    m = tmp % 60
	    local    tmp = math.floor( tmp / 60 )
	    local    h = tmp % 24
	    local curtimesys = string.format( "%02i:%02i", h, m)

		notifications_new(4, {icon = 'materials/dbt/notifications/notifications_allchat.png', title = 'Общий чат', time = curtimesys, notiftext = char..': '..msg})
	end
end)


vgui.Register("MonopadFrame", PANEL, "DFrame")
