AddCSLuaFile()
local meta = FindMetaTable("Player")

netstream.Hook("CharChangeModel", function(ply)
	local model = ply:GetModel() == "models/player/dewobedil/danganronpa/toko_fukawa/genocide_p.mdl" and "models/player/dewobedil/danganronpa/toko_fukawa/default_p.mdl" or "models/player/dewobedil/danganronpa/toko_fukawa/genocide_p.mdl"
	ply:SetModel(model)
end)

netstream.Hook("ChangeBodyGroup", function(ply, player, bgid, value)
	ply:SetBodygroup(bgid, value)
end)

netstream.Hook("RagdollPlayer", function(playergame)
	if IsValid(playergame) and playergame:Alive() and !playergame.isSpectating then
        if not playergame:InVehicle() then
			if playergame:GetNWEntity("ragdoll", nil):IsValid() then return end
            local ragdoll = ents.Create("prop_ragdoll")
			playergame.data = {}
			playergame.data.health = playergame:Health()
			playergame.data.water = playergame:GetNWInt("water")
			playergame.data.hunger = playergame:GetNWInt("hunger")
			playergame.data.sleep = playergame:GetNWInt("sleep")
			playergame.data.Stamina = playergame:GetNWInt("Stamina")

            ragdoll:SetModel(playergame:GetModel())
            ragdoll:SetPos(playergame:GetPos())
            ragdoll:Spawn()
			ragdoll:SetNWEntity("owner", playergame)

            for i = 0, playergame:GetNumBodyGroups() - 1 do
                ragdoll:SetBodygroup(i, playergame:GetBodygroup(i))
            end

			timer.Create("CheckRagdollHP"..playergame:SteamID(), 0, 0,function ()
				if playergame.data.health <= 0 then
					playergame:SetNWBool("ragdolled", false)
					playergame:SetNWEntity("ragdoll", nil)
					playergame:Spawn()
					playergame:KillSilent()
					timer.Remove("CheckRagdollHP"..playergame:SteamID())
				end
				if playergame:GetObserverTarget() ~= playergame:GetNWEntity("ragdoll", nil) then playergame:SpectateEntity(ragdoll) end
			end)

			spectator.Spectate(playergame, ragdoll, OBS_MODE_CHASE)
			playergame:SetNWEntity("ragdoll", ragdoll)
			playergame:SetNWBool("ragdolled", true)
			local PlyVel = playergame:GetVelocity()

			for ID = 0, ragdoll:GetPhysicsObjectCount()-1 do
				local PhysBone = ragdoll:GetPhysicsObjectNum( ID )
				if ( PhysBone:IsValid() ) then
					local Pos, Ang = playergame:GetBonePosition( ragdoll:TranslatePhysBoneToBone( ID ) )
					PhysBone:SetAngles( Ang )
					PhysBone:AddVelocity( PlyVel )
				end
			end
            --ply:SetNWEntity("Ragdoll", ragdoll)
        end
    end
end)

-- Function to detect hitbox from damage position
local function DetectHitboxFromDamage(ragdoll, dmgpos)
	local closestBone = nil
	local closestDistance = math.huge
	local hitbox = "unknown"
	
	-- Get all physics bones and find the closest one to damage position
	for i = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local physBone = ragdoll:GetPhysicsObjectNum(i)
		if physBone:IsValid() then
			local boneID = ragdoll:TranslatePhysBoneToBone(i)
			local bonePos = ragdoll:GetBonePosition(boneID)
			local distance = dmgpos:Distance(bonePos)
			
			if distance < closestDistance then
				closestDistance = distance
				closestBone = boneID
			end
		end
	end
	
	-- Map bone to hitbox regions
	if closestBone then
		local boneName = ragdoll:GetBoneName(closestBone):lower()
		
		-- Head hitbox
		if string.find(boneName, "head") or string.find(boneName, "neck") or string.find(boneName, "skull") then
			hitbox = "head"
		-- Chest/torso hitbox
		elseif string.find(boneName, "spine") or string.find(boneName, "chest") or string.find(boneName, "ribcage") then
			hitbox = "chest"
		-- Arm hitboxes
		elseif string.find(boneName, "arm") or string.find(boneName, "hand") or string.find(boneName, "finger") or string.find(boneName, "shoulder") then
			if string.find(boneName, "l") then
				hitbox = "left_arm"
			elseif string.find(boneName, "r") then
				hitbox = "right_arm"
			else
				hitbox = "arm"
			end
		-- Leg hitboxes
		elseif string.find(boneName, "leg") or string.find(boneName, "foot") or string.find(boneName, "toe") or string.find(boneName, "thigh") or string.find(boneName, "calf") then
			if string.find(boneName, "l") then
				hitbox = "left_leg"
			elseif string.find(boneName, "r	") then
				hitbox = "right_leg"
			else
				hitbox = "leg"
			end
		-- Pelvis/stomach
		elseif string.find(boneName, "pelvis") or string.find(boneName, "hip") then
			hitbox = "stomach"
		else
			hitbox = "torso"
		end
	end
	
	return closestBone, hitbox, closestDistance
end

hook.Add( "EntityTakeDamage", "ragdolldamage", function( target, dmginfo )
	if target:IsRagdoll() then
		local dmgpos = dmginfo:GetDamagePosition()
		local boneHit, hitbox, distance = DetectHitboxFromDamage(target, dmgpos)

		print(hitbox, target:GetBoneName(boneHit))
		if target:GetNWEntity("owner") and dmginfo:GetDamageType() ~= DMG_CRUSH then
			local ply = target:GetNWEntity("owner")
			ply.data.health = ply.data.health - dmginfo:GetDamage()
		end
	end
end )

hook.Add("PlayerButtonDown", 'ragdolldisable',function (ply, btn)
	if btn == KEY_SPACE and ply:GetNWBool("ragdolled", false) then
		spectator.UnSpectate(ply)
		if ply:GetNWEntity("ragdoll"):IsValid() then
			ply:SetPos(ply:GetNWEntity("ragdoll"):GetPos())
			ply:GetNWEntity("ragdoll"):Remove()
		end
		ply:SetNWInt("hunger", ply.data.hunger)
		ply:SetNWInt("water", ply.data.water)
		ply:SetHealth(ply.data.health)
		ply:SetNWInt("sleep", ply.data.sleep)
		ply:SetNWInt("Stamina", ply.data.Stamina)
		ply:SetNWBool("ragdolled", false)
		ply:SelectWeapon("hands")
		timer.Remove("CheckRagdollHP"..ply:SteamID())
	end
end)
