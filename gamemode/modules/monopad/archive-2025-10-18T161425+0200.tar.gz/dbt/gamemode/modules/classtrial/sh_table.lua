ct = {}

ct.pos = {}
ct.pos["drp_hopespeak"] = {}

ct.pos["drp_hopespeak"][1] = {
	vec = Vector(-198.993927, -2401.409668, -890.968750),
	ang = Angle(-90, 0, 90)
}

ct.pos["drp_hopespeak"][2] = {
	vec = Vector(-237.294479, -2404.046631, -890.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][3] = {
	vec = Vector(-277.119537, -2427.784424, -890.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][4] = {
	vec = Vector(-299.259064, -2464.632813, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][5] = {
	vec = Vector(-302.587067, -2503.415039, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][6] = {
	vec = Vector(-299.615448, -2542.131348, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][7] = {
	vec = Vector(-278.146606, -2579.162842, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][8] = {
	vec = Vector(-238.179596, -2603.758057, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][9] = {
	vec = Vector(-200.064972, -2606.583984, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][10] = {
	vec = Vector(-163.154236, -2604.140137, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][11] = {
	vec = Vector(-124.930260, -2582.238525, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}
ct.pos["drp_hopespeak"][12] = {
	vec = Vector(-100.617416, -2543.064697, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][13] = {
	vec = Vector(-97.406654, -2504.997314, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][14] = {
	vec = Vector(-100.327316, -2466.018799, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][15] = {
	vec = Vector(-122.112137, -2428.575439, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][16] = {
	vec = Vector(-160.930923, -2404.613037, -887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["drp_hopespeak"][17] = {
	vec = Vector(-198.881119, -2401.409668,-887.968750),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"] = {}


ct.pos["dgrv3_ultimateacademy"][1] = {
	vec = Vector(0, 0, 0),
	ang = Angle(-90, 0, 90)
}

ct.pos["dgrv3_ultimateacademy"][2] = {
	vec = Vector(-2198.808838, -3956.010742,171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][3] = {
	vec = Vector(-2246.291016, -3973.826416, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][4] = {
	vec = Vector(-2282.392822, -4010.500488, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][5] = {
	vec = Vector(-2300.390137, -4057.363037, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][6] = {
	vec = Vector(-2299.964844, -4106.571289, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][7] = {
	vec = Vector(-2282.823242, -4150.147949, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][8] = {
	vec = Vector(-2245.928223, -4185.293945, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][9] = {
	vec = Vector(-2202.510254, -4204.427246, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][10] = {
	vec = Vector(-2156.424316, -4205.410645, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][11] = {
	vec = Vector(-2106.354980, -4186.945313, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}
ct.pos["dgrv3_ultimateacademy"][12] = {
	vec = Vector(-2068.506836, -4149.706543, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][13] = {
	vec = Vector(-2050.129639, -4100.142578, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][14] = {
	vec = Vector(-2052.994141, -4053.871338, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][15] = {
	vec = Vector(-2071.365967, -4010.674561, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][16] = {
	vec = Vector(-2107.543945, -3973.158447, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

ct.pos["dgrv3_ultimateacademy"][17] = {
	vec = Vector(-2151.482178, -3954.115723, 171.89234924316),
	ang = Angle(29.688028, 5.065142, 0.000000)
}

