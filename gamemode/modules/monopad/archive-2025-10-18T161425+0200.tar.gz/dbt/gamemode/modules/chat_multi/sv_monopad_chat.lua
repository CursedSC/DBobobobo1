dbt.monopads = dbt.monopads or {}
dbt.monopads.list = dbt.monopads.list or {}
dbt.monopads.allchat = dbt.monopads.allchat or {}
 
function dbt.monopads.New(character)
	local id = #dbt.monopads.list + 1
	local monopad = {
		character = character,
		chats = {},
		isbreak = false,
		listen = nil,
		nowowned = nil,
	}
	dbt.monopads.list[id] = monopad
	return id
end

function dbt.monopads.FindByCharacter(character)
	for id, monopad in pairs(dbt.monopads.list) do
		if monopad.character == character then
			return id
		end
	end
	return nil
end

function dbt.monopads.Message(monopadid, monopadidFrom, message)
	local monopad = dbt.monopads.list[monopadid]
	local monopadFrom = dbt.monopads.list[monopadidFrom]
	monopad.chats[monopadidFrom] = monopad.chats[monopadidFrom] or {}
	monopad.chats[monopadidFrom][#monopad.chats[monopadidFrom] + 1] = {
		message = message,
		own = monopad.character,
			time = GetGlobalInt("Time")
	}
	monopadFrom.chats[monopadid] = monopadFrom.chats[monopadid] or {}
	monopadFrom.chats[monopadid][#monopadFrom.chats[monopadid] + 1] = {
		message = message,
		own = monopad.character,
			time = GetGlobalInt("Time")
	}

	if IsValid(monopadFrom.nowowned) then
		netstream.Start(monopadFrom.nowowned, "monopad/chat/add", monopadid, {
			message = message,
			own = monopad.character,
			time = GetGlobalInt("Time")
		})
	end
	if monopadFrom.nowowned and IsValid(monopadFrom.nowowned) then
		netstream.Start(monopadFrom.nowowned, "monopad/chat/show", monopadid, {
			message = message,
			own = monopad.character,
			time = GetGlobalInt("Time")
		})
	end

end

netstream.Hook("monopad/listen", function(ply, IsListen)
	local id = ply.info.monopad.id
	dbt.monopads.list[id].listen = IsListen
end)

netstream.Hook("dbt/monopad/request/chats", function(ply, monopadid)
	local monopad = dbt.monopads.list[monopadid]
	local SendList = {}
	for k, i in pairs(dbt.monopads.list) do
		SendList[k] = {
			id = k,
			character = i.character,
		}
	end
	netstream.Start(ply, "dbt/monopad/request/chats", SendList)
end)

netstream.Hook("dbt/monopad/request/dms", function(ply, monopadid, monopadidneed)
	if monopadidneed == "chat" then
		local SendList = dbt.monopads.allchat or {}
		netstream.Start(ply, "dbt/monopad/request/dms", SendList)
		return
	end
	local monopad = dbt.monopads.list[monopadid]
	dbt.monopads.list[monopadid].listen = monopadidneed
	local SendList = monopad.chats[monopadidneed] or {}
	netstream.Start(ply, "dbt/monopad/request/dms", SendList)
end)


netstream.Hook("dbt/monopad/send/dms", function(ply, monopadid, monopadidFrom, message, monopadsendTO)
	if monopadidFrom == "chat" then
		local monopad = dbt.monopads.list[monopadid]
		dbt.monopads.allchat[#dbt.monopads.allchat + 1] = {
			message = message,
			own = monopad.character,
			time = GetGlobalInt("Time")
		}
		netstream.Start(nil, "monopad/chat/add", "chat", {
			message = message,
			own = monopad.character,
			time = GetGlobalInt("Time")
		})

		netstream.Start(nil, "monopad/chat/notiftoall", message, monopad.character)

		return
	end
	dbt.monopads.Message(monopadid, monopadsendTO, message)
end)

netstream.Hook("dbt/monopad/admin/give", function(ply, id)
	if !ply:IsAdmin() then return end 
	local monopadTable = dbt.monopads.list[id]
	dbt.inventory.additem(ply, 1, {owner = monopadTable.character, id = id}) 
end)

netstream.Hook("dbt/monopad/admin/list", function(ply)
	if !ply:IsAdmin() then return end 
	local reforged = {}
	for k, i in pairs(dbt.monopads.list) do 
		reforged[k] = {
			character = i.character,
			isbreak = i.isbreak,
			listen = i.listen,
			nowowned = i.nowowned,		
		}
	end
	netstream.Start(ply, "dbt/monopad/admin/list", reforged)
end)
